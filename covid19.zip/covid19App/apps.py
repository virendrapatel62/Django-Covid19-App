from django.apps import AppConfig


class Covid19AppConfig(AppConfig):
    name = 'covid19App'
